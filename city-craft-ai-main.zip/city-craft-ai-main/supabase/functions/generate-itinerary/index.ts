import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
const googlePlacesApiKey = Deno.env.get('GOOGLE_PLACES_API_KEY');
const weatherApiKey = Deno.env.get('OPENWEATHERMAP_API_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { city, days, budget, interests } = await req.json();
    console.log(`Generating itinerary for ${city}, ${days} days, budget: ${budget}`);

    // Check if API key is available
    if (!googlePlacesApiKey) {
      throw new Error('Google Places API key is not configured');
    }

    // Validate city with Google Places API
    const placesUrl = `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=${encodeURIComponent(city)}&inputtype=textquery&fields=place_id,name,formatted_address,geometry&key=${googlePlacesApiKey}`;
    console.log(`Calling Google Places API for: ${city}`);
    
    const placesResponse = await fetch(placesUrl);
    const placesData = await placesResponse.json();
    
    console.log(`Google Places API response status: ${placesResponse.status}`);
    console.log(`Google Places API response:`, JSON.stringify(placesData, null, 2));
    
    if (!placesData.candidates || placesData.candidates.length === 0) {
      // Try with different formats for Indian cities
      const alternativeFormats = [
        city.charAt(0).toUpperCase() + city.slice(1).toLowerCase(),
        city.toLowerCase(),
        city.toUpperCase(),
        city + ", India"
      ];
      
      let cityInfo = null;
      for (const altCity of alternativeFormats) {
        console.log(`Trying alternative format: ${altCity}`);
        const altResponse = await fetch(
          `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=${encodeURIComponent(altCity)}&inputtype=textquery&fields=place_id,name,formatted_address,geometry&key=${googlePlacesApiKey}`
        );
        const altData = await altResponse.json();
        console.log(`Alternative format "${altCity}" response:`, JSON.stringify(altData, null, 2));
        
        if (altData.candidates && altData.candidates.length > 0) {
          console.log(`Found city with alternative format: ${altCity}`);
          cityInfo = altData.candidates[0];
          break;
        }
      }
      
      if (!cityInfo) {
        throw new Error(`City "${city}" not found. Please try with a different spelling or include the state name.`);
      }
    } else {
      var cityInfo = placesData.candidates[0];
    }
    const { lat, lng } = cityInfo.geometry.location;

    // Get weather forecast
    const weatherResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lng}&appid=${weatherApiKey}&units=metric`
    );
    const weatherData = await weatherResponse.json();

    // Generate itinerary with OpenAI
    const prompt = `Create a detailed ${days}-day travel itinerary for ${cityInfo.name} with a ${budget} budget. 
    Interests: ${interests.join(', ')}
    
    Weather forecast: ${weatherData.list.slice(0, parseInt(days)).map((day: any, index: number) => 
      `Day ${index + 1}: ${day.weather[0].description}, ${Math.round(day.main.temp)}°C`
    ).join('; ')}
    
    Return ONLY a JSON object with this exact structure:
    {
      "city": "${cityInfo.name}",
      "summary": "Brief description of the trip",
      "totalBudget": "Estimated total cost in local currency",
      "days": [
        {
          "day": 1,
          "title": "Day title",
          "items": [
            {
              "time": "09:00",
              "activity": "Activity name",
              "location": "Specific location",
              "cost": "Cost estimate",
              "description": "Brief description"
            }
          ]
        }
      ]
    }`;

    const aiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { 
            role: 'system', 
            content: 'You are a travel expert. Always respond with valid JSON only, no additional text or formatting.' 
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
      }),
    });

    const aiData = await aiResponse.json();
    const itineraryText = aiData.choices[0].message.content;
    
    // Parse the JSON response
    const itinerary = JSON.parse(itineraryText);
    
    console.log('Successfully generated itinerary for', city);
    
    return new Response(JSON.stringify(itinerary), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error generating itinerary:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to generate itinerary' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});