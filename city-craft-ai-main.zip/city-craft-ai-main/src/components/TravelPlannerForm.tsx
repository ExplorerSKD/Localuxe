import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, DollarSign, Sparkles, Shuffle } from "lucide-react";

interface TravelFormData {
  city: string;
  days: string;
  budget: string;
  interests: string[];
}

interface TravelPlannerFormProps {
  onSubmit: (data: TravelFormData) => void;
  isLoading?: boolean;
}

const interestTags = [
  "Temples", "Street Food", "Nature & Wildlife", "Local Markets", "Heritage", "Festivals", 
  "Adventure Sports", "Culture", "Art & Handicrafts", "Architecture", "Hill Stations", "Photography",
  "Ayurveda & Wellness", "Bollywood", "Rural Experience", "Spiritual Journey"
];

export function TravelPlannerForm({ onSubmit, isLoading = false }: TravelPlannerFormProps) {
  const [formData, setFormData] = useState<TravelFormData>({
    city: "",
    days: "",
    budget: "",
    interests: []
  });

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleSurpriseMe = () => {
    const cities = ["Goa", "Rajasthan", "Kerala", "Himachal Pradesh", "Uttarakhand", "Karnataka", "Tamil Nadu", "Maharashtra", "West Bengal", "Jammu & Kashmir"];
    const randomCity = cities[Math.floor(Math.random() * cities.length)];
    const randomDays = Math.floor(Math.random() * 7) + 1;
    const randomBudget = ["Low", "Medium", "High"][Math.floor(Math.random() * 3)];
    const randomInterests = interestTags
      .sort(() => 0.5 - Math.random())
      .slice(0, Math.floor(Math.random() * 4) + 2);
    
    setFormData({
      city: randomCity,
      days: randomDays.toString(),
      budget: randomBudget,
      interests: randomInterests
    });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-travel bg-card/95 backdrop-blur-sm">
      <CardHeader className="text-center space-y-4">
        <CardTitle className="text-3xl font-bold bg-gradient-wanderlust bg-clip-text text-transparent">
          Plan Your Perfect Trip
        </CardTitle>
        <p className="text-muted-foreground">
          Tell us your destination and preferences, and we'll create a personalized itinerary
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* City Input */}
          <div className="space-y-2">
            <Label htmlFor="city" className="flex items-center gap-2 text-sm font-medium">
              <MapPin className="w-4 h-4" />
              Destination City
            </Label>
            <Input
              id="city"
              type="text"
              placeholder="e.g., Goa, Rajasthan, Kerala, Mumbai..."
              value={formData.city}
              onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
              className="h-12 text-base"
              required
            />
          </div>

          {/* Days and Budget */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="days" className="flex items-center gap-2 text-sm font-medium">
                <Calendar className="w-4 h-4" />
                Number of Days
              </Label>
              <Input
                id="days"
                type="number"
                min="1"
                max="30"
                placeholder="3"
                value={formData.days}
                onChange={(e) => setFormData(prev => ({ ...prev, days: e.target.value }))}
                className="h-12 text-base"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budget" className="flex items-center gap-2 text-sm font-medium">
                <DollarSign className="w-4 h-4" />
                Budget Level
              </Label>
              <select
                id="budget"
                value={formData.budget}
                onChange={(e) => setFormData(prev => ({ ...prev, budget: e.target.value }))}
                className="w-full h-12 text-base rounded-md border border-input bg-background px-3 py-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                required
              >
                <option value="">Select budget</option>
                <option value="Low">Budget-friendly</option>
                <option value="Medium">Moderate</option>
                <option value="High">Luxury</option>
              </select>
            </div>
          </div>

          {/* Interest Tags */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2 text-sm font-medium">
              <Sparkles className="w-4 h-4" />
              Your Interests (Optional)
            </Label>
            <div className="flex flex-wrap gap-2">
              {interestTags.map((interest) => (
                <Badge
                  key={interest}
                  variant={formData.interests.includes(interest) ? "default" : "outline"}
                  className={`cursor-pointer transition-smooth hover:scale-105 ${
                    formData.interests.includes(interest) 
                      ? "bg-primary hover:bg-primary/90" 
                      : "hover:bg-accent"
                  }`}
                  onClick={() => handleInterestToggle(interest)}
                >
                  {interest}
                </Badge>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button
              type="submit"
              disabled={isLoading}
              variant="wanderlust"
              size="lg"
              className="flex-1"
            >
              {isLoading ? "Creating Your Itinerary..." : "Generate Itinerary"}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={handleSurpriseMe}
              className="sm:w-auto"
            >
              <Shuffle className="w-4 h-4" />
              Surprise Me!
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}