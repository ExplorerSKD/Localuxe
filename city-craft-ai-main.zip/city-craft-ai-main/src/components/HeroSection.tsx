import { Plane, MapPin, Sparkles } from "lucide-react";

export function HeroSection() {
  return (
    <div className="relative min-h-[60vh] flex items-center justify-center bg-gradient-hero overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 animate-float">
          <Plane className="w-8 h-8 text-primary-foreground transform rotate-45" />
        </div>
        <div className="absolute top-40 right-32 animate-float" style={{ animationDelay: '1s' }}>
          <MapPin className="w-6 h-6 text-primary-foreground" />
        </div>
        <div className="absolute bottom-32 left-40 animate-float" style={{ animationDelay: '2s' }}>
          <Sparkles className="w-7 h-7 text-primary-foreground" />
        </div>
        <div className="absolute top-60 right-20 animate-float" style={{ animationDelay: '0.5s' }}>
          <MapPin className="w-5 h-5 text-primary-foreground" />
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center space-y-6 px-6 max-w-4xl mx-auto">
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-bold text-primary-foreground tracking-tight">
            Localuxe
          </h1>
          <div className="flex items-center justify-center gap-2 text-primary-foreground/90">
            <Sparkles className="w-6 h-6" />
            <span className="text-xl font-medium">AI Travel Itinerary Generator</span>
            <Sparkles className="w-6 h-6" />
          </div>
        </div>
        
        <p className="text-xl md:text-2xl text-primary-foreground/90 leading-relaxed">
          Stop spending hours researching. Get a personalized, day-by-day travel plan 
          <br className="hidden md:block" />
          tailored to your interests and budget in seconds.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-6 pt-8 text-primary-foreground/80">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            <span>Smart Planning</span>
          </div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            <span>AI-Powered</span>
          </div>
          <div className="flex items-center gap-2">
            <Plane className="w-5 h-5" />
            <span>Instant Results</span>
          </div>
        </div>
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/20 pointer-events-none" />
    </div>
  );
}