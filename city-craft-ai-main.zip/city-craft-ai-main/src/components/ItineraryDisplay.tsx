import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, MapPin, DollarSign, Share2, Download } from "lucide-react";

interface ItineraryItem {
  time: string;
  activity: string;
  location: string;
  description: string;
  estimatedCost: string;
  coordinates?: [number, number];
}

interface DayPlan {
  day: number;
  title: string;
  items: ItineraryItem[];
  totalCost: string;
}

interface ItineraryData {
  city: string;
  days: DayPlan[];
  totalBudget: string;
  summary: string;
}

interface ItineraryDisplayProps {
  itinerary: ItineraryData;
  onShare?: () => void;
  onExport?: () => void;
}

export function ItineraryDisplay({ itinerary, onShare, onExport }: ItineraryDisplayProps) {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-slide-in">
      {/* Header */}
      <Card className="shadow-travel bg-gradient-ocean text-primary-foreground">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold">
            Your Perfect Trip to {itinerary.city}
          </CardTitle>
          <p className="text-primary-foreground/90 text-lg">
            {itinerary.summary}
          </p>
          <div className="flex items-center justify-center gap-4 pt-4">
            <Badge variant="secondary" className="text-sm px-3 py-1">
              <DollarSign className="w-4 h-4 mr-1" />
              Total Budget: {itinerary.totalBudget}
            </Badge>
            <Badge variant="secondary" className="text-sm px-3 py-1">
              {itinerary.days.length} Days
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-center gap-3">
        <Button variant="outline" onClick={onShare}>
          <Share2 className="w-4 h-4" />
          Share Itinerary
        </Button>
        <Button variant="outline" onClick={onExport}>
          <Download className="w-4 h-4" />
          Export PDF
        </Button>
      </div>

      {/* Daily Plans */}
      <div className="space-y-6">
        {itinerary.days.map((day, dayIndex) => (
          <Card key={dayIndex} className="shadow-soft">
            <CardHeader className="bg-gradient-sunset text-primary-foreground rounded-t-lg">
              <CardTitle className="flex items-center justify-between">
                <span>Day {day.day}: {day.title}</span>
                <Badge variant="secondary" className="text-accent-foreground">
                  {day.totalCost}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-0">
                {day.items.map((item, itemIndex) => (
                  <div 
                    key={itemIndex}
                    className={`p-6 border-b border-border/50 hover:bg-muted/30 transition-smooth ${
                      itemIndex === day.items.length - 1 ? 'border-b-0 rounded-b-lg' : ''
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                      <div className="flex items-center gap-3 lg:w-32 flex-shrink-0">
                        <Clock className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-lg">{item.time}</span>
                      </div>
                      
                      <div className="flex-1 space-y-2">
                        <h4 className="text-xl font-semibold text-primary">{item.activity}</h4>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          <span>{item.location}</span>
                        </div>
                        <p className="text-foreground leading-relaxed">{item.description}</p>
                      </div>
                      
                      <div className="flex items-center gap-2 lg:w-24 flex-shrink-0">
                        <DollarSign className="w-4 h-4 text-accent" />
                        <span className="font-medium text-accent">{item.estimatedCost}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Map Placeholder */}
      <Card className="shadow-travel">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Interactive Map
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="w-full h-64 bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg flex items-center justify-center">
            <div className="text-center space-y-2">
              <MapPin className="w-12 h-12 mx-auto text-primary animate-float" />
              <p className="text-muted-foreground">Map will be integrated here</p>
              <p className="text-sm text-muted-foreground">
                Showing all locations from your itinerary
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}