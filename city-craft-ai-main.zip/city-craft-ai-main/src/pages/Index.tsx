import { useState } from "react";
import { HeroSection } from "@/components/HeroSection";
import { TravelPlannerForm } from "@/components/TravelPlannerForm";
import { ItineraryDisplay } from "@/components/ItineraryDisplay";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface TravelFormData {
  city: string;
  days: string;
  budget: string;
  interests: string[];
}

// Mock data for demonstration
const mockItinerary = {
  city: "Rajasthan",
  days: [
    {
      day: 1,
      title: "Royal Heritage & Culture",
      totalCost: "₹3,200",
      items: [
        {
          time: "8:00 AM",
          activity: "City Palace Visit",
          location: "City Palace Road, Jaipur",
          description: "Explore the magnificent City Palace complex showcasing royal artifacts, courtyards, and stunning architecture of the Pink City.",
          estimatedCost: "₹700",
          coordinates: [75.8267, 26.9255] as [number, number]
        },
        {
          time: "11:30 AM",
          activity: "Hawa Mahal",
          location: "Hawa Mahal Road, Badi Choupad",
          description: "Marvel at the iconic Palace of Winds with its unique honeycomb facade and 953 small windows designed for royal ladies.",
          estimatedCost: "₹200",
          coordinates: [75.8267, 26.9239] as [number, number]
        },
        {
          time: "1:00 PM",
          activity: "Traditional Rajasthani Thali",
          location: "Chokhi Dhani Village Resort",
          description: "Savor authentic dal-baati-churma, gatte ki sabzi, and other traditional Rajasthani delicacies in a cultural village setting.",
          estimatedCost: "₹800",
          coordinates: [75.7047, 26.7839] as [number, number]
        },
        {
          time: "4:00 PM",
          activity: "Amber Fort & Elephant Ride",
          location: "Devisinghpura, Amer, Jaipur",
          description: "Experience the grandeur of Amber Fort with its mirror work, gardens, and optional elephant ride up the ramparts.",
          estimatedCost: "₹1,500",
          coordinates: [75.8515, 26.9855] as [number, number]
        }
      ]
    },
    {
      day: 2,
      title: "Desert Culture & Handicrafts",
      totalCost: "₹2,800",
      items: [
        {
          time: "9:00 AM",
          activity: "Jantar Mantar Observatory",
          location: "Gangori Bazaar, J.D.A. Market",
          description: "Discover the world's largest stone astronomical observatory with 19 architectural astronomical instruments.",
          estimatedCost: "₹200",
          coordinates: [75.8245, 26.9247] as [number, number]
        },
        {
          time: "11:00 AM",
          activity: "Local Markets & Shopping",
          location: "Johari Bazaar & Bapu Bazaar",
          description: "Shop for traditional Rajasthani jewelry, textiles, blue pottery, and handicrafts in the bustling local markets.",
          estimatedCost: "₹1,500",
          coordinates: [75.8231, 26.9196] as [number, number]
        },
        {
          time: "2:00 PM",
          activity: "Block Printing Workshop",
          location: "Sanganer Village",
          description: "Learn traditional block printing techniques and create your own textile souvenir with local artisans.",
          estimatedCost: "₹600",
          coordinates: [75.7849, 26.8390] as [number, number]
        },
        {
          time: "6:00 PM",
          activity: "Cultural Evening & Dinner",
          location: "Nahargarh Fort",
          description: "Enjoy traditional Rajasthani folk dance, music performances, and dinner with panoramic city views.",
          estimatedCost: "₹1,200",
          coordinates: [75.8154, 26.9344] as [number, number]
        }
      ]
    }
  ],
  totalBudget: "₹6,000",
  summary: "A perfect 2-day journey through Rajasthan's royal heritage, featuring majestic forts, traditional cuisine, local handicrafts, and cultural experiences."
};

const Index = () => {
  const [itinerary, setItinerary] = useState<typeof mockItinerary | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFormSubmit = async (formData: TravelFormData) => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-itinerary', {
        body: formData
      });
      
      if (error) throw error;
      
      setItinerary(data);
      toast.success(`Your ${formData.city} itinerary is ready!`);
    } catch (error) {
      toast.error("Failed to generate itinerary. Please try again.");
      console.error("Error generating itinerary:", error);
      // Fallback to mock data if API fails
      const customizedItinerary = {
        ...mockItinerary,
        city: formData.city,
        summary: `A perfect ${formData.days}-day adventure in ${formData.city} tailored to your interests and ${formData.budget.toLowerCase()} budget.`
      };
      setItinerary(customizedItinerary);
    } finally {
      setIsLoading(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `My ${itinerary?.city} Travel Itinerary`,
        text: `Check out my AI-generated travel plan for ${itinerary?.city}!`,
        url: window.location.href,
      });
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  };

  const handleExport = () => {
    toast.info("PDF export feature coming soon!");
  };

  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      
      <div className="container mx-auto px-6 py-12 space-y-12">
        {!itinerary ? (
          <TravelPlannerForm onSubmit={handleFormSubmit} isLoading={isLoading} />
        ) : (
          <ItineraryDisplay 
            itinerary={itinerary} 
            onShare={handleShare}
            onExport={handleExport}
          />
        )}
        
        {itinerary && (
          <div className="text-center">
            <button
              onClick={() => setItinerary(null)}
              className="text-primary hover:text-primary/80 underline transition-smooth"
            >
              Plan Another Trip
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
